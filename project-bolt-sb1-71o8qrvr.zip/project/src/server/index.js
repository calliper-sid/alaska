import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

// Load environment variables
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Create Express app
const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());

// Placeholder for Gemini API integration
app.post('/api/generate-question', (req, res) => {
  const { topic, difficulty } = req.body;
  
  // In a real implementation, this would call the Gemini API
  // For demo purposes, we're returning sample questions
  const questions = {
    'Arrays-Easy': {
      title: 'Find the Maximum Element',
      description: 'Write a function that finds the maximum element in an array of integers.',
      example: {
        input: '[3, 7, 2, 8, 1]',
        output: '8'
      },
      constraints: 'The array will contain at least one element and all elements will be integers.'
    },
    'Arrays-Medium': {
      title: 'Subarray Sum',
      description: 'Find a continuous subarray whose sum equals the target value.',
      example: {
        input: 'arr = [1, 2, 3, 4, 5], target = 9',
        output: '[2, 3, 4] (indices 1-3, with values 2+3+4=9)'
      },
      constraints: 'The array can contain positive and negative integers.'
    }
  };
  
  // Default to a generic question if the requested combination isn't available
  const question = questions[`${topic}-${difficulty}`] || {
    title: 'Coding Challenge',
    description: `Write a solution for a ${difficulty.toLowerCase()} problem related to ${topic.toLowerCase()}.`,
    example: {
      input: 'Sample input',
      output: 'Expected output'
    },
    constraints: 'Follow good coding practices and optimize your solution.'
  };
  
  // Simulate API delay
  setTimeout(() => {
    res.json({ question });
  }, 500);
});

// Serve static files in production
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../../dist')));
  
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../../dist/index.html'));
  });
}

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});