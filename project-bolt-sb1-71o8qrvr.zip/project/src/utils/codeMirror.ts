import { EditorState } from '@codemirror/state';
import { EditorView, keymap } from '@codemirror/view';
import { defaultKeymap, history, historyKeymap } from '@codemirror/commands';
import { syntaxHighlighting, defaultHighlightStyle } from '@codemirror/language';
import { javascript } from '@codemirror/lang-javascript';

export function createEditor(
  element: HTMLElement,
  initialValue: string,
  onUpdate: (value: string) => void
) {
  const updateListener = EditorView.updateListener.of((update) => {
    if (update.docChanged) {
      onUpdate(update.state.doc.toString());
    }
  });

  const state = EditorState.create({
    doc: initialValue,
    extensions: [
      history(),
      keymap.of([...defaultKeymap, ...historyKeymap]),
      javascript(),
      syntaxHighlighting(defaultHighlightStyle),
      EditorView.lineWrapping,
      updateListener,
      EditorState.tabSize.of(2),
      EditorView.theme({
        "&": {
          fontSize: "14px",
          height: "350px"
        },
        ".cm-scroller": {
          fontFamily: "JetBrains Mono, monospace",
        },
        ".cm-content": {
          padding: "10px 0"
        },
        ".cm-line": {
          padding: "0 15px",
          lineHeight: "1.6"
        },
        ".cm-activeLine": {
          backgroundColor: "#f8fafc"
        },
        ".cm-gutters": {
          backgroundColor: "#f8fafc",
          color: "#64748b",
          border: "none"
        },
        ".cm-activeLineGutter": {
          backgroundColor: "#f1f5f9"
        }
      })
    ]
  });

  const view = new EditorView({
    state,
    parent: element
  });

  return { editor: element, view };
}