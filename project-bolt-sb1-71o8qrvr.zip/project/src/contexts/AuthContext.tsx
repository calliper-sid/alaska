import React, { createContext, useContext, useState, useEffect } from 'react';
import { useSupabase } from './SupabaseContext';

interface User {
  id: string;
  username: string;
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (username: string, password: string) => Promise<{ error: any | null }>;
  register: (username: string, password: string) => Promise<{ error: any | null }>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const { supabase } = useSupabase();

  useEffect(() => {
    // Check for user in local storage on initial load
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (error) {
        console.error('Failed to parse stored user:', error);
        localStorage.removeItem('user');
      }
    }
    setLoading(false);
  }, []);

  const login = async (username: string, password: string) => {
    try {
      // In a real app, you would use proper authentication
      // This is a simple example to demonstrate the basic concept
      const { data, error } = await supabase
        .from('users')
        .select('id, username')
        .eq('username', username)
        .eq('password', password) // Note: In a real app, you would never store plain passwords!
        .single();

      if (error) {
        console.error('Login error:', error);
        return { error };
      }

      // Store user in state and localStorage
      const userData = { id: data.id, username: data.username };
      setUser(userData);
      localStorage.setItem('user', JSON.stringify(userData));
      return { error: null };
    } catch (error) {
      console.error('Login error:', error);
      return { error };
    }
  };

  const register = async (username: string, password: string) => {
    try {
      // Check if username is already taken
      const { data: existingUser, error: checkError } = await supabase
        .from('users')
        .select('id')
        .eq('username', username)
        .single();

      if (existingUser) {
        return { error: { message: 'Username already taken' } };
      }

      // Insert new user
      const { data, error } = await supabase
        .from('users')
        .insert([{ username, password }]) // In a real app, hash the password!
        .select('id, username')
        .single();

      if (error) {
        console.error('Register error:', error);
        return { error };
      }

      // Store user in state and localStorage
      const userData = { id: data.id, username: data.username };
      setUser(userData);
      localStorage.setItem('user', JSON.stringify(userData));
      return { error: null };
    } catch (error) {
      console.error('Register error:', error);
      return { error };
    }
  };

  const logout = () => {
    // Clear user from state and localStorage
    setUser(null);
    localStorage.removeItem('user');
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
};