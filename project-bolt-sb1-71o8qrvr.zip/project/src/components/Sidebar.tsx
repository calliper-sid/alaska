import React from 'react';
import { NavLink } from 'react-router-dom';
import { User, Code, BrainCircuit, X } from 'lucide-react';
import { motion } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';

interface SidebarProps {
  isOpen: boolean;
  toggleSidebar: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, toggleSidebar }) => {
  const { logout } = useAuth();

  const navItems = [
    { name: 'Profile', path: '/profile', icon: <User className="w-5 h-5" /> },
    { name: 'Practice', path: '/practice', icon: <Code className="w-5 h-5" /> },
    { name: 'Generate', path: '/generate', icon: <BrainCircuit className="w-5 h-5" /> },
  ];

  return (
    <>
      {/* Mobile sidebar backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-20 bg-black bg-opacity-50 transition-opacity md:hidden"
          onClick={toggleSidebar}
        ></div>
      )}

      {/* Sidebar */}
      <aside
        className={`fixed top-0 left-0 z-30 h-full w-64 transform bg-white pt-16 transition-transform duration-300 ease-in-out md:translate-x-0 md:static md:z-auto ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="h-full overflow-y-auto border-r border-gray-200">
          <div className="flex items-center justify-between p-4 md:hidden">
            <h2 className="text-lg font-medium text-gray-900">Navigation</h2>
            <button
              type="button"
              className="rounded-md p-2 text-gray-500 hover:bg-gray-100"
              onClick={toggleSidebar}
            >
              <span className="sr-only">Close sidebar</span>
              <X className="h-5 w-5" aria-hidden="true" />
            </button>
          </div>
          
          <nav className="mt-4 space-y-1 px-2">
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) =>
                  `group flex items-center px-2 py-2 text-sm font-medium rounded-md ${
                    isActive
                      ? 'bg-primary-50 text-primary-700'
                      : 'text-gray-700 hover:bg-gray-50 hover:text-gray-900'
                  }`
                }
                onClick={() => {
                  if (window.innerWidth < 768) {
                    toggleSidebar();
                  }
                }}
              >
                {({ isActive }) => (
                  <motion.div
                    className="flex items-center w-full"
                    whileHover={{ x: 4 }}
                    transition={{ duration: 0.2 }}
                  >
                    <span className={`mr-3 ${isActive ? 'text-primary-600' : 'text-gray-500'}`}>
                      {item.icon}
                    </span>
                    {item.name}
                  </motion.div>
                )}
              </NavLink>
            ))}
            
            <hr className="my-4 border-gray-200" />
            
            <button
              onClick={logout}
              className="group flex w-full items-center px-2 py-2 text-sm font-medium text-gray-700 rounded-md hover:bg-gray-50 hover:text-gray-900"
            >
              <motion.div
                className="flex items-center w-full"
                whileHover={{ x: 4 }}
                transition={{ duration: 0.2 }}
              >
                <span className="mr-3 text-gray-500">
                  <LogOut className="w-5 h-5" />
                </span>
                Logout
              </motion.div>
            </button>
          </nav>
        </div>
      </aside>
    </>
  );
};

const LogOut = ({ className }: { className: string }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
    <polyline points="16 17 21 12 16 7" />
    <line x1="21" y1="12" x2="9" y2="12" />
  </svg>
);

export default Sidebar;