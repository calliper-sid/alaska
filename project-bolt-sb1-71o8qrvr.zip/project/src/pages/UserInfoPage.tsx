import React, { useState, useEffect } from 'react';
import { useSupabase } from '../contexts/SupabaseContext';
import { useAuth } from '../contexts/AuthContext';
import { motion } from 'framer-motion';
import { CheckCircle, AlertCircle } from 'lucide-react';

interface UserProfile {
  name: string;
  college: string;
  skill_level: 'Beginner' | 'Intermediate' | 'Advanced';
  preferred_languages: string[];
}

const programmingLanguages = [
  'C', 'C++', 'Java', 'Python', 'JavaScript', 'TypeScript',
  'Go', 'Rust', 'Swift', 'Ruby', 'PHP', 'C#'
];

const UserInfoPage: React.FC = () => {
  const { supabase } = useSupabase();
  const { user } = useAuth();
  const [profile, setProfile] = useState<UserProfile>({
    name: '',
    college: '',
    skill_level: 'Beginner',
    preferred_languages: []
  });
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [notification, setNotification] = useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);

  useEffect(() => {
    const fetchUserProfile = async () => {
      if (!user) return;

      try {
        const { data, error } = await supabase
          .from('profiles')
          .select('name, college, skill_level, preferred_languages')
          .eq('user_id', user.id)
          .single();

        if (error && error.code !== 'PGRST116') {
          // PGRST116 is "no rows returned" error, which is expected for new users
          console.error('Error fetching profile:', error);
        }

        if (data) {
          setProfile(data);
        }
      } catch (error) {
        console.error('Error fetching profile:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchUserProfile();
  }, [user, supabase]);

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setProfile((prev) => ({ ...prev, [name]: value }));
  };

  const handleLanguageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value, checked } = e.target;
    setProfile((prev) => {
      if (checked) {
        return {
          ...prev,
          preferred_languages: [...prev.preferred_languages, value]
        };
      } else {
        return {
          ...prev,
          preferred_languages: prev.preferred_languages.filter(lang => lang !== value)
        };
      }
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setIsSaving(true);
    setNotification(null);

    try {
      const { error } = await supabase
        .from('profiles')
        .upsert(
          {
            user_id: user.id,
            name: profile.name,
            college: profile.college,
            skill_level: profile.skill_level,
            preferred_languages: profile.preferred_languages,
            updated_at: new Date().toISOString()
          },
          { onConflict: 'user_id' }
        );

      if (error) {
        throw error;
      }

      setNotification({
        type: 'success',
        message: 'Profile updated successfully'
      });

      // Hide the notification after 3 seconds
      setTimeout(() => {
        setNotification(null);
      }, 3000);
    } catch (error) {
      console.error('Error updating profile:', error);
      setNotification({
        type: 'error',
        message: 'Failed to update profile'
      });
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Your Profile</h1>
          <p className="text-gray-600 mt-1">
            Complete your profile to personalize your coding experience
          </p>
        </div>

        {notification && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className={`mb-6 p-4 rounded-md flex items-center
              ${notification.type === 'success' ? 'bg-success-50 text-success-700' : 'bg-error-50 text-error-700'}`}
          >
            {notification.type === 'success' ? (
              <CheckCircle className="h-5 w-5 mr-2" />
            ) : (
              <AlertCircle className="h-5 w-5 mr-2" />
            )}
            {notification.message}
          </motion.div>
        )}

        <div className="bg-white shadow-sm rounded-lg overflow-hidden">
          <form onSubmit={handleSubmit} className="p-6">
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
              <div className="col-span-2 sm:col-span-1">
                <label htmlFor="name" className="label">
                  Full Name
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={profile.name}
                  onChange={handleInputChange}
                  className="input"
                  placeholder="John Doe"
                  required
                />
              </div>

              <div className="col-span-2 sm:col-span-1">
                <label htmlFor="college" className="label">
                  College/University
                </label>
                <input
                  type="text"
                  id="college"
                  name="college"
                  value={profile.college}
                  onChange={handleInputChange}
                  className="input"
                  placeholder="Stanford University"
                  required
                />
              </div>

              <div className="col-span-2">
                <label htmlFor="skill_level" className="label">
                  Coding Skill Level
                </label>
                <select
                  id="skill_level"
                  name="skill_level"
                  value={profile.skill_level}
                  onChange={handleInputChange}
                  className="select"
                  required
                >
                  <option value="Beginner">Beginner</option>
                  <option value="Intermediate">Intermediate</option>
                  <option value="Advanced">Advanced</option>
                </select>
              </div>

              <div className="col-span-2">
                <label className="label mb-2">
                  Preferred Programming Languages
                </label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {programmingLanguages.map((language) => (
                    <div key={language} className="flex items-center">
                      <input
                        type="checkbox"
                        id={`lang-${language}`}
                        name="preferred_languages"
                        value={language}
                        checked={profile.preferred_languages.includes(language)}
                        onChange={handleLanguageChange}
                        className="checkbox"
                      />
                      <label
                        htmlFor={`lang-${language}`}
                        className="ml-2 text-sm text-gray-700"
                      >
                        {language}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-8">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                type="submit"
                className="btn-primary"
                disabled={isSaving}
              >
                {isSaving ? 'Saving...' : 'Save Profile'}
              </motion.button>
            </div>
          </form>
        </div>
      </motion.div>
    </div>
  );
};

export default UserInfoPage;