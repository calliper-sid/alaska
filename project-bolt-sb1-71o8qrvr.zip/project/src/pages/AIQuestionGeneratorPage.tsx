import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { BrainCircuit, LightbulbIcon, Loader } from 'lucide-react';
import { GoogleGenerativeAI } from '@genkit-ai/google';

const topics = [
  'Arrays',
  'Strings',
  'Linked Lists',
  'Stacks',
  'Queues',
  'Trees',
  'Graphs',
  'Recursion',
  'Dynamic Programming',
  'Sorting',
  'Searching',
  'Hashing',
];

const difficulties = [
  'Easy',
  'Medium',
  'Hard',
];

const AIQuestionGeneratorPage: React.FC = () => {
  const [topic, setTopic] = useState<string>('Arrays');
  const [difficulty, setDifficulty] = useState<string>('Easy');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generatedQuestion, setGeneratedQuestion] = useState<string | null>(null);

  const handleGenerateQuestion = async () => {
    setIsGenerating(true);
    setGeneratedQuestion(null);
    
    try {
      const genAI = new GoogleGenerativeAI(import.meta.env.VITE_GEMINI_API_KEY);
      const model = genAI.getGenerativeModel({ model: 'gemini-pro' });

      const prompt = `Generate a coding question about ${topic} with ${difficulty} difficulty level. 
      Format the response in markdown with the following sections:
      1. Problem title (as h1)
      2. Problem description
      3. Example input and output
      4. Constraints
      Make it challenging but appropriate for the difficulty level.`;

      const result = await model.generateContent(prompt);
      const response = await result.response;
      const text = response.text();
      setGeneratedQuestion(text);
    } catch (error) {
      console.error('Error generating question:', error);
      setGeneratedQuestion('Failed to generate a question. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">AI Question Generator</h1>
          <p className="text-gray-600 mt-1">
            Generate custom coding questions powered by AI to practice your skills
          </p>
        </div>

        <div className="bg-white shadow-sm rounded-lg overflow-hidden mb-6">
          <div className="p-6">
            <div className="flex flex-col sm:flex-row sm:items-center gap-4">
              <div className="flex-1">
                <label htmlFor="topic" className="label">
                  Topic
                </label>
                <select
                  id="topic"
                  className="select"
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                >
                  {topics.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex-1">
                <label htmlFor="difficulty" className="label">
                  Difficulty
                </label>
                <select
                  id="difficulty"
                  className="select"
                  value={difficulty}
                  onChange={(e) => setDifficulty(e.target.value)}
                >
                  {difficulties.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex-shrink-0 flex items-end">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="btn-primary h-10"
                  onClick={handleGenerateQuestion}
                  disabled={isGenerating}
                >
                  {isGenerating ? (
                    <>
                      <Loader className="h-4 w-4 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <BrainCircuit className="h-4 w-4 mr-2" />
                      Generate Question
                    </>
                  )}
                </motion.button>
              </div>
            </div>
          </div>
        </div>

        {isGenerating && (
          <div className="bg-white shadow-sm rounded-lg p-8 mb-6 flex flex-col items-center justify-center">
            <div className="w-16 h-16 border-4 border-primary-200 border-t-primary-600 rounded-full animate-spin mb-4"></div>
            <p className="text-gray-600 text-center">
              AI is crafting a {difficulty.toLowerCase()} question about {topic.toLowerCase()}...
            </p>
          </div>
        )}

        {generatedQuestion && !isGenerating && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="bg-white shadow-sm rounded-lg overflow-hidden mb-6"
          >
            <div className="bg-primary-50 px-6 py-4 flex items-center border-b border-primary-100">
              <LightbulbIcon className="h-5 w-5 text-primary-600 mr-2" />
              <h2 className="text-lg font-medium text-primary-900">Generated Question</h2>
            </div>
            <div className="p-6">
              <div className="prose max-w-none">
                {generatedQuestion.split('\n').map((line, index) => {
                  if (line.startsWith('# ')) {
                    return <h2 key={index} className="text-xl font-bold mb-4">{line.substring(2)}</h2>;
                  } else if (line.startsWith('## ')) {
                    return <h3 key={index} className="text-lg font-semibold mt-4 mb-2">{line.substring(3)}</h3>;
                  } else if (line.startsWith('- ')) {
                    return <li key={index} className="ml-6 mb-1">{line.substring(2)}</li>;
                  } else if (line.startsWith('  - ')) {
                    return <li key={index} className="ml-12 mb-1">{line.substring(4)}</li>;
                  } else if (line.trim() === '') {
                    return <br key={index} />;
                  } else {
                    return <p key={index} className="mb-2">{line}</p>;
                  }
                })}
              </div>
            </div>
            <div className="px-6 py-4 bg-gray-50 border-t border-gray-100 flex justify-end">
              <button
                onClick={() => {
                  window.location.href = '/practice';
                }}
                className="btn-primary"
              >
                Practice This Question
              </button>
            </div>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
};

export default AIQuestionGeneratorPage;