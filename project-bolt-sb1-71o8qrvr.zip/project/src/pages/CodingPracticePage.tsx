import React, { useState, useEffect } from 'react';
import { createEditor } from '../utils/codeMirror';
import { motion } from 'framer-motion';
import { Code, Play, RefreshCw } from 'lucide-react';

const CodingPracticePage: React.FC = () => {
  const [code, setCode] = useState<string>(
    '// Write your solution here\nfunction reverseString(str) {\n  // Your code\n  return str;\n}'
  );
  const [editorElement, setEditorElement] = useState<HTMLElement | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  // Sample problem
  const problem = {
    title: 'Reverse a String',
    description: 'Write a function that reverses a string.',
    example: {
      input: '"hello"',
      output: '"olleh"'
    },
    constraints: 'The input string will only contain lowercase letters and whitespace.',
    difficulty: 'Easy'
  };

  // Initialize CodeMirror
  useEffect(() => {
    if (!editorElement) return;

    const { editor, view } = createEditor(editorElement, code, (newCode) => {
      setCode(newCode);
    });

    // Cleanup function
    return () => {
      view.destroy();
    };
  }, [editorElement, code]);

  const handleSubmit = () => {
    setIsSubmitting(true);
    // Simulate submission delay
    setTimeout(() => {
      setIsSubmitting(false);
      setShowSuccess(true);
      // Hide success message after 3 seconds
      setTimeout(() => {
        setShowSuccess(false);
      }, 3000);
    }, 1000);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{problem.title}</h1>
              <div className="mt-1 flex items-center">
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                  {problem.difficulty}
                </span>
              </div>
            </div>
            <button
              onClick={() => window.location.reload()}
              className="btn-outline flex items-center text-sm"
            >
              <RefreshCw className="h-4 w-4 mr-1" />
              Reset Code
            </button>
          </div>
        </div>

        <div className="bg-white shadow-sm rounded-lg overflow-hidden mb-6">
          <div className="p-6">
            <div className="mb-6">
              <h2 className="text-lg font-medium text-gray-900 mb-2">Description</h2>
              <p className="text-gray-700">{problem.description}</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
              <div>
                <h3 className="text-sm font-medium text-gray-900 mb-2">Example Input</h3>
                <div className="bg-gray-50 p-3 rounded font-mono text-sm">{problem.example.input}</div>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-900 mb-2">Expected Output</h3>
                <div className="bg-gray-50 p-3 rounded font-mono text-sm">{problem.example.output}</div>
              </div>
            </div>

            <div className="mb-4">
              <h3 className="text-sm font-medium text-gray-900 mb-2">Constraints</h3>
              <p className="text-gray-700 text-sm">{problem.constraints}</p>
            </div>
          </div>
        </div>

        <div className="bg-white shadow-sm rounded-lg overflow-hidden mb-6">
          <div className="border-b border-gray-200 px-6 py-4 flex items-center justify-between">
            <div className="flex items-center">
              <Code className="h-5 w-5 text-gray-400 mr-2" />
              <h2 className="text-lg font-medium text-gray-900">Solution</h2>
            </div>
            <div>
              <select className="select text-sm py-1" defaultValue="javascript">
                <option value="javascript">JavaScript</option>
                <option value="python">Python</option>
                <option value="java">Java</option>
                <option value="cpp">C++</option>
              </select>
            </div>
          </div>
          <div 
            ref={(el) => setEditorElement(el)} 
            className="border-gray-200"
          ></div>
          <div className="px-6 py-4 flex justify-end">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleSubmit}
              className="btn-primary flex items-center"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Submitting...
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 mr-2" />
                  Submit Solution
                </>
              )}
            </motion.button>
          </div>
        </div>

        {showSuccess && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="bg-success-50 text-success-700 p-4 rounded-md flex items-center mb-6"
          >
            <CheckCircle className="h-5 w-5 mr-2" />
            Solution submitted successfully!
          </motion.div>
        )}
      </motion.div>
    </div>
  );
};

const CheckCircle = ({ className }: { className: string }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
    <polyline points="22 4 12 14.01 9 11.01" />
  </svg>
);

export default CodingPracticePage;