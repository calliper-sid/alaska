import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './contexts/AuthContext';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import UserInfoPage from './pages/UserInfoPage';
import CodingPracticePage from './pages/CodingPracticePage';
import AIQuestionGeneratorPage from './pages/AIQuestionGeneratorPage';
import Layout from './components/Layout';
import LoadingScreen from './components/LoadingScreen';

function RequireAuth({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();

  if (loading) {
    return <LoadingScreen />;
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
}

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/" element={
          <RequireAuth>
            <Layout />
          </RequireAuth>
        }>
          <Route index element={<Navigate to="/profile" replace />} />
          <Route path="profile" element={<UserInfoPage />} />
          <Route path="practice" element={<CodingPracticePage />} />
          <Route path="generate" element={<AIQuestionGeneratorPage />} />
        </Route>
      </Routes>
    </div>
  );
}

export default App;